# Konig Art Hub — Static Website (GitHub Pages)

This package contains a ready-to-upload static website for **Konig Art Hub**:
- Dark-themed, modern design
- Pages: Home, Gallery, About, Shop, Contact
- Placeholder images and social links

## How to publish on GitHub Pages (quick)
1. Create a GitHub account if you don't have one: https://github.com
2. Create a new repository named: `yourusername.github.io` (replace `yourusername`)
3. Upload all files from this package to the repository root (commit them).
4. Visit `https://yourusername.github.io` — your site should be live within a minute.

If you'd like, I can:
- Customize text, add real social links, or replace placeholders with real images.
- Help with committing the files via Git commands or the GitHub web UI.

Enjoy! — Konig Art Hub starter
